
echo "plaintext.txt :"
cat plaintext.txt
echo ""
echo ""

echo "ciphertext_output.txt :"
cat ciphertext_output.txt
echo ""
echo ""

echo "signature_output.txt :"
cat signature_output.txt
echo ""
echo ""

echo "plaintext_roundtrip.txt :"
cat plaintext_roundtrip.txt
echo ""
echo ""

echo "hsmsecret.txt :"
cat hsmsecret.txt
echo ""
echo ""

echo "user_passwordhash_output.txt :"
cat user_passwordhash_output.txt
echo ""
echo ""

echo "user_KeyIDs_output.txt :"
cat user_KeyIDs_output.txt
echo ""
echo ""

echo "publickey_keyID_output.txt :"
cat publickey_keyID_output.txt
echo ""
echo ""

echo "privatekey_keyID_output.txt :"
cat privatekey_keyID_output.txt
echo ""
echo ""

echo "keyid_KEK_output.txt :"
cat keyid_KEK_output.txt
echo ""
echo ""

echo "keyid_KVC_output.txt :"
cat keyid_KVC_output.txt
echo ""
echo ""