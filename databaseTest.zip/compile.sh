javac Main.java && java Main $1
